const { test } = require("node:test");
const assert = require("node:assert/strict");
const C = require("../app/src/main/assets/core.js");
const D = "2026-11-17";
const run = (s, a, p = {}, date = D) => {
  const n = structuredClone(s);
  C.apply(n, a, p, date);
  return C.validate(n);
};
test("fresh account has zero financial and game balances", () => {
  const s = C.fresh();
  assert.equal(C.balance(s), 0);
  assert.equal(C.xp(s), 0);
  assert.equal(C.coins(s), 0);
  assert.equal(C.level(s).n, 1);
});
test("currency uses integer kopecks, including comma", () => {
  assert.equal(C.amount("0,10"), 10);
  let s = run(C.fresh(), "txAdd", {
    kind: "income",
    amount: "0.30",
    date: D,
    category: "Доход",
  });
  s = run(s, "txAdd", {
    kind: "expense",
    amount: "0,10",
    date: D,
    category: "Еда",
  });
  assert.equal(C.balance(s), 20);
  for (const v of ["-3", "1e3", "0", "1.005", "NaN", "Infinity"])
    assert.throws(() => C.amount(v));
});
test("invalid calendar dates are rejected", () => {
  assert.equal(C.validDate("2026-02-30"), false);
  assert.equal(C.validDate("2028-02-29"), true);
});
test("habit requires evidence and rewards once per day", () => {
  let s = C.fresh();
  assert.throws(() => run(s, "habitComplete", { id: "move", value: 1 }));
  s = run(s, "habitComplete", { id: "move", value: 20, note: "Прогулка" });
  assert.equal(C.xp(s), 20);
  assert.equal(C.coins(s), 4);
  assert.throws(() => run(s, "habitComplete", { id: "move", value: 30 }));
  s = run(s, "habitComplete", { id: "move", value: 20 }, "2026-11-18");
  assert.equal(C.xp(s), 40);
});
test("finance reward is once a day after edits/deletion", () => {
  let s = run(C.fresh(), "txAdd", {
    kind: "income",
    amount: "100",
    date: D,
    category: "Доход",
  });
  const id = s.tx[0].id;
  s = run(s, "txEdit", {
    id,
    kind: "expense",
    amount: "25.50",
    date: D,
    category: "Еда",
  });
  assert.equal(C.balance(s), -2550);
  s = run(s, "txDelete", { id });
  s = run(s, "txAdd", {
    kind: "expense",
    amount: "1",
    date: D,
    category: "Еда",
  });
  assert.equal(C.xp(s), 10);
});
test("recurring payment idempotent per month, history remains on plan removal", () => {
  let s = run(C.fresh(), "billAdd", {
      name: "Связь",
      amount: "500.99",
      day: 31,
      category: "Дом",
    }),
    id = s.bills[0].id;
  s = run(s, "billPay", { id });
  assert.equal(s.tx.length, 1);
  assert.throws(() => run(s, "billPay", { id }));
  s = run(s, "billPay", { id }, "2026-12-01");
  assert.equal(s.tx.length, 2);
  s = run(s, "billDelete", { id });
  assert.equal(C.balance(s), -100198);
});
test("budgets replace the same category/month only", () => {
  let s = run(C.fresh(), "budget", {
    month: "2026-11",
    category: "Дом",
    amount: "100",
  });
  s = run(s, "budget", { month: "2026-11", category: "Дом", amount: "200" });
  s = run(s, "budget", { month: "2026-12", category: "Дом", amount: "300" });
  assert.equal(s.budgets.length, 2);
  assert.equal(s.budgets[0].cents, 20000);
});
test("task completion requires a real result, reward persists after deletion", () => {
  let s = run(C.fresh(), "taskAdd", {
      name: "Прочесть главу",
      date: D,
      skill: "mind",
    }),
    id = s.tasks[0].id;
  assert.throws(() => run(s, "taskComplete", { id, note: "" }));
  s = run(s, "taskComplete", { id, note: "Записал 3 идеи" });
  assert.equal(C.xp(s), 25);
  assert.throws(() => run(s, "taskComplete", { id, note: "Ещё раз" }));
  s = run(s, "taskDelete", { id });
  assert.equal(C.xp(s), 25);
});
test("goal rewards each milestone and final completion exactly once", () => {
  let s = run(C.fresh(), "goalAdd", {
      name: "Мой маршрут",
      date: D,
      steps: "Купить обувь\nПройти 5 км",
    }),
    id = s.goals[0].id;
  for (const t of [...s.goals[0].steps])
    s = run(s, "goalStep", { id, step: t.id, note: "Сделано в реальности" });
  assert.equal(C.xp(s), 110);
  assert.equal(C.level(s).n, 2);
  assert.throws(() =>
    run(s, "goalStep", { id, step: s.goals[0].steps[0].id, note: "Повтор" }),
  );
});
test("health deletion and re-add cannot farm rewards", () => {
  let s = run(C.fresh(), "workout", { minutes: 20, type: "Прогулка" });
  s = run(s, "healthDelete", { collection: "workouts", id: s.workouts[0].id });
  s = run(s, "workout", { minutes: 30, type: "Йога" });
  assert.equal(C.xp(s), 25);
  s = run(s, "meal", { name: "Овощи с рисом", kcal: "", type: "Обед" });
  s = run(s, "meal", { name: "Творог", kcal: 200, type: "Перекус" });
  assert.equal(C.xp(s), 35);
  s = run(s, "weight", { kg: 75.2 });
  s = run(s, "weight", { kg: 75.1 });
  assert.equal(C.xp(s), 35);
  assert.equal(s.weights.length, 1);
});
test("purchases cannot overspend or duplicate", () => {
  let s = C.fresh();
  assert.throws(() => run(s, "outfit", { id: "sunset" }));
  s.legacy = { xp: 500, coins: 100 };
  s = run(s, "outfit", { id: "sunset" });
  assert.equal(C.coins(s), 55);
  s = run(s, "outfit", { id: "trail" });
  s = run(s, "outfit", { id: "sunset" });
  assert.equal(C.coins(s), 55);
  assert.throws(() => run(s, "outfit", { id: "night" }));
});
test("v0.8 migration preserves real transactions and progress, excludes marked demo", () => {
  let s = C.migrate({
    v: 2,
    onboard: true,
    xp: 220,
    coins: 50,
    profile: { name: "Анна", tone: "#E9B18C" },
    tx: [
      { id: "real", kind: "income", amount: 12.34, category: "Дом", date: D },
      {
        id: "demo",
        kind: "income",
        amount: 1000,
        category: "Дом",
        date: D,
        demo: true,
      },
    ],
    tasks: [{ id: "t", name: "Чтение", due: D, done: true }],
    logs: { [D]: ["move"] },
  });
  assert.equal(C.balance(s), 1234);
  assert.equal(C.xp(s), 220);
  assert.equal(s.profile.name, "Анна");
  assert.equal(C.habitDone(s, "move", D), true);
  assert.throws(() => run(s, "habitComplete", { id: "move", value: 20 }));
  assert.equal(s.tasks[0].done, true);
});
test("schema round trip retains data", () => {
  const s = run(C.fresh(), "txAdd", {
    kind: "income",
    amount: "123.45",
    date: D,
    category: "Доход",
  });
  assert.deepEqual(C.migrate(JSON.parse(JSON.stringify(s))), s);
});
test("malformed import fails before mutation", () => {
  const s = C.fresh();
  for (const mutate of [
    (n) => n.tx.push({ cents: NaN }),
    (n) => n.rewards.push({ key: "bad", xp: -1 }),
    (n) => n.goals.push({ name: "x", steps: null }),
    (n) => (n.settings.music = 10),
    (n) => (n.revision = -1),
  ]) {
    const n = structuredClone(s);
    mutate(n);
    assert.throws(() => C.validate(n));
  }
  assert.equal(C.balance(s), 0);
});
test("streak crosses month boundary and allows unfinished today", () => {
  const s = C.fresh();
  for (const d of ["2026-10-30", "2026-10-31", "2026-11-01"])
    C.apply(s, "habitComplete", { id: "move", value: 20 }, d);
  assert.equal(C.streak(s, "2026-11-02"), 3);
  assert.equal(C.streak(s, "2026-11-03"), 0);
});
test("date rollback cannot duplicate the same source reward", () => {
  let s = run(C.fresh(), "meal", { name: "Обед", kcal: 100 });
  s = run(s, "meal", { name: "Ужин", kcal: 300 }, "2026-11-18");
  s = run(s, "meal", { name: "Повтор", kcal: 100 }, D);
  assert.equal(C.xp(s), 20);
});
